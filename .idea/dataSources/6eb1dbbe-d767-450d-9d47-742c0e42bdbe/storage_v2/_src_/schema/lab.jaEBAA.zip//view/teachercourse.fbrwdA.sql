create definer = root@localhost view teachercourse as
select `t2`.`teacher_id` AS `teacher_id`,
       `t1`.`name`       AS `name`,
       `t1`.`rank_name`  AS `rank_name`,
       `t2`.`course_id`  AS `course_id`,
       `t3`.`name`       AS `name`,
       `t3`.`dept_name`  AS `dept_name`
from ((`lab`.`teaches` `t2` left join `lab`.`teacher` `t1` on ((`t1`.`id` = `t2`.`teacher_id`)))
         left join `lab`.`course` `t3` on ((`t2`.`course_id` = `t3`.`id`)));

