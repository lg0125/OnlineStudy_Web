create definer = root@localhost view messageshow as
select `t1`.`id`         AS `id`,
       `t1`.`status`     AS `status`,
       `t1`.`title`      AS `title`,
       `t1`.`content`    AS `content`,
       `t1`.`time`       AS `time`,
       `t1`.`student_id` AS `student_id`,
       `t2`.`name`       AS `name`,
       `t2`.`photo`      AS `photo`,
       `t1`.`course_id`  AS `course_id`,
       `t4`.`name`       AS `name`,
       `t4`.`dept_name`  AS `dept_name`,
       `t1`.`teacher_id` AS `teacher_id`,
       `t3`.`name`       AS `name`
from (((`lab`.`message` `t1` left join `lab`.`student` `t2` on ((`t1`.`student_id` = `t2`.`id`))) left join `lab`.`teacher` `t3` on ((`t1`.`teacher_id` = `t3`.`id`)))
         left join `lab`.`course` `t4` on ((`t1`.`course_id` = `t4`.`id`)));

