create definer = root@localhost view coursestudent as
select `t1`.`id`     AS `id`,
       `t1`.`name`   AS `name`,
       `t4`.`id`     AS `id`,
       `t4`.`name`   AS `name`,
       `t3`.`id`     AS `id`,
       `t3`.`name`   AS `name`,
       `t2`.`status` AS `status`
from (((`lab`.`takes` `t2` left join `lab`.`student` `t1` on ((`t1`.`id` = `t2`.`student_id`))) left join `lab`.`teacher` `t3` on ((`t2`.`teacher_id` = `t3`.`id`)))
         left join `lab`.`course` `t4` on ((`t2`.`course_id` = `t4`.`id`)));

