create definer = root@localhost view replyshow as
select `t1`.`id`         AS `id`,
       `t1`.`message_id` AS `message_id`,
       `t1`.`content`    AS `content`,
       `t1`.`time`       AS `time`,
       `t2`.`teacher_id` AS `teacher_id`,
       `t3`.`name`       AS `name`,
       `t3`.`rank_name`  AS `rank_name`,
       `t3`.`photo`      AS `photo`
from ((`lab`.`reply` `t1` left join `lab`.`message` `t2` on ((`t1`.`message_id` = `t2`.`id`)))
         left join `lab`.`teacher` `t3` on ((`t2`.`teacher_id` = `t3`.`id`)));

